Action Bar icons are conventionally prefixed with ic_menu_, thus
templates are available in the -v11 subdirectories of the
ic_menu_template directory.
